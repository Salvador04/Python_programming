import setuptools

setuptools.setup(
	name = 'python_class',
	packages = ["python_class"]
)

